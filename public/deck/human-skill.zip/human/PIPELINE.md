# Human, detalhe de cada passe

O que cada estagio do pipeline checa e corrige. Base: doc do Igor + blader/humanizer + Wikipedia "Signs of AI writing" + pesquisa 2024-2026 (detector e probabilistico; tells valem em cluster; texto curto e onde detector falha, entao foco e qualidade/voz real).

## 0. SCAN (gate de entrada)
- Rodar `scripts/scan.py`. Ler score, veredito (PASS/QUASE/FAIL) e cada tell com peso.
- Usar a lista como mapa: cada tell aponta o passe que vai resolver.
- Burstiness baixa no relatorio = frases uniformes (resolver no passe RHYTHM). Lembrar: burstiness e sinal de QUALIDADE de escrita, nao prova de IA (e dependente de modelo).

## 1. STRIP, cortar o aquecimento
- Remover: cumprimento, "neste post vamos...", "e importante notar que", "vale ressaltar", tom servil de chatbot ("claro!", "espero que ajude", "aqui esta uma versao").
- Cortar transicoes nao merecidas empilhadas ("Alem disso", "Ademais", "Por fim", "Dessa forma") quando nao carregam logica.
- Entrar direto no ponto na primeira frase.

## 2. THESIS, achar a coluna
- Responder em 1 frase: "qual e o ponto real deste texto?".
- Se nao der pra responder, parar e definir a tese antes de reescrever.
- A tese forte vai pro comeco (abertura). Boas aberturas: contradicao, consequencia concreta, detalhe estranho, frase de conversa real, ou "todo mundo olha isso errado". Evitar abertura generica sobre tecnologia/futuro.

## 3. MECHANISM, abstracao para concreto
- Principio: REESCREVER, nao deletar. A versao nova cobre tudo que a original cobria.
- Trocar "transforma o mercado" por COMO: reduz custo? muda distribuicao? automatiza etapa? cria dependencia? concentra poder?
- Teste de especificidade, cada afirmacao forte precisa de pelo menos um: numero, nome, mecanismo, antes/depois, consequencia concreta, quem ganha e quem perde.
- Adicionar detalhe dificil de fabricar (o que mais separa humano de IA).

## 4. RHYTHM, ritmo e estrutura
- Variar tamanho de frase: curta pra impacto, media pra explicar, longa so quando a ideia precisa respirar. Alternar de proposito (sobe a burstiness).
- Quebrar regra de tres quando a triade nao e necessaria (virar 2 ideias ou 1 frase concreta).
- Desfazer paralelismo negativo ("nao so X, mas Y") e antitese explicita ("nao e X, e Y") quando viram tique.
- Copula avoidance: trocar "se posiciona como / serve como / ostenta" por "e / tem / faz".
- Cortar variacao elegante (ciclar sinonimo so pra nao repetir) e falsas amplitudes ("de X a Y" decorativo).

## 5. VOICE, voz e opiniao
- Injetar julgamento: "o que me chama atencao e...", "o detalhe incomodo e...", "o risco e menos obvio". Sem neutralidade absoluta.
- Permitir alguma "bagunca" humana: uma tangente curta, uma frase solta depois de uma longa.
- Se houver amostra da voz do Igor, calibrar comprimento de frase, vocabulario e pontuacao por ela antes de finalizar.

## 6. VERIFY, gate de saida
- Passe diagnostico: reler e listar em bullets "o que AINDA soa IA aqui?". Corrigir cada item.
- Conferir fechamento: terminar com consequencia, tensao, pergunta especifica, tese resumida ou CTA direto. Evitar "o futuro e promissor", "so o tempo dira", "fica claro que".
- Zero em dash e en dash.
- Rodar `scripts/scan.py` de novo. Se nao for PASS, voltar ao passe do tell que sobrou e repetir.
- Entregar texto + veredito antes/depois.

## Nota sobre detectores
Nao prometer "passa no GPTZero/Originality/Pangram". Em texto curto eles sao pouco confiaveis e a deteccao e probabilistica. O pipeline otimiza naturalidade real; passar em detector e consequencia, nao meta.
