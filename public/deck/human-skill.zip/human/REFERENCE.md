# Human, referencia completa

Listas e exemplos no padrao do Igor. Base: notas do proprio Igor + taxonomia consolidada de blader/humanizer, conorbronsdon/avoid-ai-writing e Wikipedia "Signs of AI writing".

---

## Formulas proibidas (cortar sempre)
- "pouco detalhe, muito impacto"
- "na mao certa"
- "nao e X, e Y" / "nao e apenas X, e Y" / "mais do que X, e Y"
- "o futuro ja chegou"
- "isso muda tudo"
- "a pergunta nao e se, mas quando"
- "o verdadeiro ponto e"
- "no fim do dia"
- "em um mundo cada vez mais..."
- "no cenario atual"
- "a nova era de..."
- "um divisor de aguas" / "um marco importante" / "uma mudanca de paradigma"

Regra: se a frase poderia estar em qualquer post de LinkedIn sobre qualquer assunto, corta.

## Palavras infladas (so com prova ao lado)
crucial, essencial, revolucionario, transformador, inovador, robusto, poderoso, vibrante, rico em, profundo, impressionante, fascinante, sem precedentes, altamente relevante, cenario em evolucao, ecossistema, jornada, alavancar, potencializar, destravar, impulsionar.

Ruim: "A ferramenta promete revolucionar o ecossistema de criacao."
Melhor: "A ferramenta troca tres etapas do processo por uma conversa: voce mostra o video, pede a mudanca e ve a versao editada."

## Frases de aquecimento (entrar direto)
"vamos explorar", "vamos mergulhar", "vamos entender", "neste post, vamos ver", "aqui esta o que voce precisa saber", "sem mais delongas", "e importante notar que", "vale destacar que".

Ruim: "Neste post, vamos entender por que a decisao dos EUA e importante."
Melhor: "Os EUA nao proibiram um app. Proibiram uma capacidade."

## Falsa profundidade (trocar por consequencia real)
"isso reflete uma tendencia maior", "isso simboliza uma mudanca profunda", "isso destaca a importancia de...", "isso evidencia o papel crucial de...", "isso serve como lembrete de...", "isso representa um novo capitulo".

## Tom servil de chatbot (nunca no texto final)
"claro!", "com certeza!", "otima pergunta", "espero que ajude", "se quiser, posso...", "aqui esta uma versao...", "fiz uma analise detalhada...". Isso e interface, nao texto.

## Ritmo
Alternar frase curta (impacto), media (explica) e longa (so quando a ideia precisa respirar). Evitar listas de tres quando a triade nao e necessaria: quebrar em duas ideias ou virar uma frase concreta.

## Aberturas (escolher uma)
Trazer uma contradicao; mostrar consequencia concreta; comecar pelo detalhe estranho; abrir com frase de conversa real; apontar o que todo mundo olha errado.

Evitar: "Nos ultimos anos, a inteligencia artificial tem avancado...", "Em um mundo cada vez mais digital...", "A tecnologia esta transformando a forma como vivemos...".

## Fechamentos
Fechar com consequencia, tensao, pergunta especifica, frase curta que resume a tese, ou CTA direto (se for post).
Evitar: "o futuro e promissor", "so o tempo dira", "estamos apenas no comeco", "as possibilidades sao infinitas", "o impacto sera enorme", "fica claro que...".

## Opiniao e voz (usar quando fizer sentido)
"o que me chama atencao aqui e...", "o detalhe incomodo e...", "essa parte parece pequena, mas nao e", "o risco e menos obvio", "isso parece tecnico, mas e uma disputa de distribuicao", "eu nao acho que o ponto seja...".

---

## Taxonomia de tells (fontes externas, conferir tambem)
- **Conteudo:** inflar significancia/legado, name-dropping de cobertura, analises rasas com gerundio ("-ndo"), tom de propaganda, atribuicao vaga ("especialistas dizem"), secao formulaica de "desafios e futuro".
- **Lingua:** evitar o verbo "ser" ("se posiciona como" em vez de "e"), paralelismo negativo ("nao X, mas Y"), regra de tres em excesso, variacao elegante (trocar sinonimo so pra nao repetir), falsos intervalos ("de X a Y").
- **Estilo/forma:** em dash e en dash, negrito em excesso, listas com cabecalho em negrito + dois pontos, Title Case, emoji como bullet, aspas curvas.
- **Comunicacao:** abre/fecha de chatbot, ressalva de "data de corte", confianca/hedge em excesso, conclusao positiva generica.
- **Meta:** hashtags empilhadas, placeholder esquecido, baixa diversidade de vocabulario.

---

## Antes e depois
1. Antes: "A inteligencia artificial esta transformando profundamente a forma como empresas operam, criando novas oportunidades e desafios em um cenario cada vez mais competitivo."
   Depois: "A IA esta entrando no lugar onde a empresa ja trabalha. Primeiro no email. Depois no documento. Depois na reuniao. Quando voce percebe, o software virou colega de trabalho."
2. Antes: "Esse movimento representa uma mudanca de paradigma no mercado de tecnologia."
   Depois: "Esse movimento muda a disputa. A pergunta deixa de ser quem tem o melhor chatbot e passa a ser quem aparece mais vezes no dia do usuario."
3. Antes: "Nao e apenas uma ferramenta, e uma nova forma de pensar produtividade."
   Depois: "A ferramenta tira uma etapa do caminho: voce nao precisa abrir outro app pra pedir ajuda a IA. Ela ja esta dentro do fluxo."
4. Antes: "Pouco detalhe, muito impacto."
   Depois: cortar a frase e mostrar o detalhe que causa o impacto.

---

## Regras especificas (posts do Igor)
Portugues brasileiro; frase direta vence frase bonita; tese forte logo no comeco; sem tom de professor generico; sem jargao de marketing sem prova; cada slide avanca a narrativa; sem cliche de IA/copy pronto; sem conclusao morna; em carrossel o texto cabe sem reticencias; se ficou grande, cortar ideia secundaria, nao diminuir a fonte ate ficar feio.

---

## Bloco-prompt pronto (revisao rapida)
"Revise este texto para tirar cara de IA. Corte frases genericas, formulas prontas, tom publicitario, listas de tres forcadas, introducoes de aquecimento e conclusoes vagas. Preserve a tese, deixe o texto mais direto, com ritmo humano, opiniao e detalhes concretos. Proibido usar: 'pouco detalhe, muito impacto', 'na mao certa', 'nao e X, e Y', 'em um mundo cada vez mais', 'mudanca de paradigma', 'isso muda tudo', 'o futuro ja chegou'. Sem em dash nem en dash."
