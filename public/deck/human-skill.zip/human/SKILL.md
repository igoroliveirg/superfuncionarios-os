---
name: human
description: Pipeline de humanizacao de texto em portugues (posts, carrosseis, copy curta, roteiros, legendas, e-mails) no padrao de escrita do Igor. Roda uma sequencia de passes com um linter deterministico (scan.py) como porta de entrada e saida: mede os tells de IA, reescreve cortando formula pronta, tom publicitario, aquecimento, copula avoidance, regra de tres, falsa profundidade e conclusao vaga, varia o ritmo, injeta voz, e so termina quando o texto passa no scan. Use when o usuario invocar /human, pedir pra "humanizar", "tirar cara de IA/ChatGPT", "deixar mais humano/natural", revisar ou reescrever post/carrossel/legenda/roteiro/copy, ou disser que um texto "soa robotico/generico/corporativo".
---

# Human, pipeline de humanizacao (pt-BR, padrao Igor)

## O que este comando faz
Roda os passes na ordem abaixo, um depois do outro, e usa o linter `scripts/scan.py` como gate objetivo: mede antes, reescreve, mede de novo, e so entrega quando o texto passa. Tells de IA aparecem em **cluster**, nao isolados, entao o gate e por score somado, nao por um sinal unico.

**Verdade de base (pesquisa 2024-2026):** detector de IA e probabilistico e fraco em texto curto (post/carrossel). Entao a meta NAO e enganar detector: e deixar o texto genuinamente humano, com tese, voz, ritmo e detalhe. Se ficar bom de verdade, passa de quebra.

## Pipeline (executar em ordem)

**0. SCAN (gate de entrada)** — rodar o linter e ler os achados:
```
python3 ~/.claude/skills/human/scripts/scan.py <arquivo>
# ou: echo "texto" | python3 ~/.claude/skills/human/scripts/scan.py
```
Anota o score e cada tell. Esse mapa guia os passes seguintes.

**1. STRIP** — cortar aquecimento, tom servil e transicao vazia. Entrar direto no ponto.

**2. THESIS** — responder em 1 frase "qual e o ponto real?". Se nao der, o texto nao tem coluna; achar antes de seguir.

**3. MECHANISM** — trocar abstracao por mecanismo concreto. Reescrever, nao deletar: cobrir tudo que o original cobria. Cada afirmacao forte ganha numero, nome, antes/depois, consequencia ou quem ganha/perde.

**4. RHYTHM** — variar tamanho de frase (curta/media/longa) pra subir a burstiness; quebrar regra de tres e paralelismo. Trocar copula avoidance ("se posiciona como") por verbo direto ("e").

**5. VOICE** — injetar julgamento e ponto de vista. Sem neutralidade absoluta. Se houver amostra da voz do Igor, calibrar frase, vocabulario e pontuacao por ela.

**6. VERIFY (gate de saida)** — passe diagnostico ("o que AINDA soa IA aqui?") + rodar o scan de novo. Zero em dash e en dash (trocar por virgula, dois pontos, parenteses). Se o scan nao der PASS, voltar ao passe do tell que sobrou. Repetir ate passar.

## Regras fixas
- Sempre o mais sucinto (cortar verbo auxiliar e rodeio): "chega" > "passa a chegar".
- Zero em dash / en dash.
- Carrossel: uma ideia por slide, texto grande, sem reticencias, CTA final inteiro. Se nao cabe, cortar ideia secundaria, nao encolher a fonte.
- Regra de ouro: se a frase parece inteligente mas nao muda o entendimento, corta. Se parece simples mas faz enxergar de outro jeito, mantem.

## Saida
Entregar o texto reescrito + o veredito do scan (antes -> depois). Se o usuario pedir, mostrar a lista de tells corrigidos.

## Referencia
Listas completas de tells, exemplos antes/depois, taxonomia das fontes e bloco-prompt: [REFERENCE.md](REFERENCE.md). O que cada passe checa em detalhe: [PIPELINE.md](PIPELINE.md).
