#!/usr/bin/env python3
"""scan.py, linter deterministico anti-cara-de-IA (pt-BR, padrao Igor).

Uso:
    python3 scan.py <arquivo.txt|.md>
    echo "texto" | python3 scan.py
    python3 scan.py --json <arquivo>     # saida JSON

Pontua o texto contra tells de escrita de IA e devolve achados + veredito.
Sem dependencias (stdlib). Acentos sao normalizados pra casar com ou sem acento.
Exit code: 0 se PASS, 1 se FAIL (tem tells a corrigir).
"""
import json
import re
import sys
import unicodedata

# --- pesos por categoria (quanto maior, mais grave) ---
W = {"formula": 3, "inflada": 1, "aquecimento": 2, "falsa_profundidade": 2,
     "servil": 3, "dash": 2, "conclusao": 2, "rule_of_three": 1, "burstiness": 2,
     "copula": 2, "transicao": 1}

# copula avoidance: trocar "e/sao" por verbo de marketing (tell de IA)
COPULA = [
    "se posiciona como", "posiciona-se como", "se configura como",
    "se apresenta como", "apresenta-se como", "se destaca como",
    "se consolida como", "se estabelece como", "serve como", "ostenta",
    "representa um", "funciona como uma verdadeira",
]
# transicoes nao merecidas (denuncia quando empilhadas)
TRANSICOES = [
    "alem disso", "ademais", "outrossim", "dessa forma", "desse modo",
    "nesse sentido", "por conseguinte", "por fim,", "vale ressaltar",
    "em suma", "portanto,",
]

FORMULAS = [
    "pouco detalhe, muito impacto", "na mao certa", "nao e apenas", "nao e so",
    "mais do que", "o futuro ja chegou", "isso muda tudo",
    "a pergunta nao e se, mas quando", "o verdadeiro ponto e", "no fim do dia",
    "em um mundo cada vez mais", "num mundo cada vez mais", "no cenario atual",
    "a nova era", "divisor de aguas", "marco importante", "mudanca de paradigma",
    "nos ultimos anos", "a tecnologia esta transformando",
]
# "nao e X, e Y" / "nao e apenas X, e Y" (paralelismo negativo)
NEG_PARALLEL = re.compile(r"\bnao e\b[^.;!?\n]{0,60}?,?\s+\be\b\s", re.I)

INFLADAS = [
    "crucial", "essencial", "revolucionario", "transformador", "inovador",
    "robusto", "poderoso", "vibrante", "rico em", "impressionante",
    "fascinante", "sem precedentes", "altamente relevante", "cenario em evolucao",
    "ecossistema", "jornada", "alavancar", "potencializar", "destravar",
    "impulsionar",
]
AQUECIMENTO = [
    "vamos explorar", "vamos mergulhar", "vamos entender", "neste post",
    "neste artigo", "aqui esta o que voce precisa saber", "sem mais delongas",
    "e importante notar que", "e importante ressaltar", "vale destacar que",
    "vale lembrar que", "antes de mais nada",
]
FALSA_PROF = [
    "isso reflete uma tendencia", "isso simboliza", "isso destaca a importancia",
    "isso evidencia o papel", "isso serve como lembrete", "isso representa um novo capitulo",
    "ao seu cerne", "em sua essencia", "em ultima analise",
]
SERVIL = [
    "claro!", "com certeza!", "otima pergunta", "espero que ajude",
    "se quiser, posso", "aqui esta uma versao", "fiz uma analise detalhada",
    "espero que isso", "fico feliz em ajudar",
]
CONCLUSAO = [
    "o futuro e promissor", "so o tempo dira", "estamos apenas no comeco",
    "as possibilidades sao infinitas", "o impacto sera enorme", "fica claro que",
    "uma coisa e certa", "resta acompanhar", "o ceu e o limite",
]


def strip_accents(s: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", s)
                   if unicodedata.category(c) != "Mn")


def norm(s: str) -> str:
    return strip_accents(s.lower())


def find_phrases(text_norm: str, phrases, category):
    hits = []
    for p in phrases:
        pn = norm(p)
        idx = text_norm.find(pn)
        if idx != -1:
            hits.append((category, p, idx))
    return hits


def sentences(text: str):
    parts = re.split(r"(?<=[.!?])\s+|\n+", text.strip())
    return [s.strip() for s in parts if s.strip()]


def scan(text: str):
    tn = norm(text)
    findings = []

    for cat, phrases in [("formula", FORMULAS), ("inflada", INFLADAS),
                         ("aquecimento", AQUECIMENTO),
                         ("falsa_profundidade", FALSA_PROF),
                         ("servil", SERVIL), ("conclusao", CONCLUSAO),
                         ("copula", COPULA)]:
        for c, p, _ in find_phrases(tn, phrases, cat):
            findings.append({"cat": c, "trecho": p, "peso": W[c]})

    # transicoes nao merecidas: so denuncia quando empilhadas (3+)
    trans_hits = [p for _, p, _ in find_phrases(tn, TRANSICOES, "transicao")]
    if len(trans_hits) >= 3:
        findings.append({"cat": "transicao", "peso": W["transicao"] * len(trans_hits),
                         "trecho": f"{len(trans_hits)} transicoes empilhadas",
                         "nota": ", ".join(trans_hits)})

    # paralelismo negativo "nao e X, e Y"
    for m in NEG_PARALLEL.finditer(text):
        findings.append({"cat": "formula", "trecho": m.group(0).strip()[:60],
                         "peso": W["formula"], "nota": "paralelismo negativo"})

    # em dash / en dash
    for ch in ("—", "–"):
        n = text.count(ch)
        if n:
            findings.append({"cat": "dash", "trecho": f"{n}x '{ch}'",
                             "peso": W["dash"] * n, "nota": "trocar por virgula/dois pontos/parenteses"})

    # burstiness: variacao de tamanho de frase
    sents = sentences(text)
    lengths = [len(s.split()) for s in sents]

    # rule of three: "a, b e c". Tell quando COMPULSIVO (densidade alta),
    # nao quando aparece pontual numa pagina longa. Densidade = triades/frase.
    triples = re.findall(r"\b[\wÀ-ſ]+,\s+[\wÀ-ſ]+\s+e\s+[\wÀ-ſ]+\b", text)
    n_sents = max(1, len(sents))
    dens = len(triples) / n_sents
    compulsivo = (dens >= 0.08) or (len(sents) <= 6 and len(triples) >= 2)
    if len(triples) >= 2 and compulsivo:
        findings.append({"cat": "rule_of_three",
                         "trecho": f"{len(triples)} listas de tres (densidade {dens:.0%})",
                         "peso": W["rule_of_three"] * min(len(triples), 4),
                         "nota": "; ".join(triples[:3])})
    burst = None
    if len(lengths) >= 4:
        mean = sum(lengths) / len(lengths)
        var = sum((x - mean) ** 2 for x in lengths) / len(lengths)
        burst = round(var ** 0.5, 1)
        if burst < 4.0:
            findings.append({"cat": "burstiness", "trecho": f"desvio de frase {burst} (baixo)",
                             "peso": W["burstiness"],
                             "nota": "alternar frase curta/media/longa"})

    score = sum(f["peso"] for f in findings)
    verdict = "PASS" if score == 0 else ("QUASE" if score <= 3 else "FAIL")
    return {"score": score, "verdict": verdict, "n_frases": len(sents),
            "burstiness": burst, "findings": findings}


def main():
    args = [a for a in sys.argv[1:] if a != "--json"]
    as_json = "--json" in sys.argv
    if args:
        text = open(args[0], encoding="utf-8").read()
    else:
        text = sys.stdin.read()
    rep = scan(text)
    if as_json:
        print(json.dumps(rep, ensure_ascii=False, indent=2))
    else:
        print(f"VEREDITO: {rep['verdict']}  (score {rep['score']}, "
              f"{rep['n_frases']} frases, burstiness {rep['burstiness']})")
        if not rep["findings"]:
            print("Nenhum tell encontrado. Texto limpo.")
        for f in rep["findings"]:
            nota = f"  <- {f['nota']}" if f.get("nota") else ""
            print(f"  [{f['cat']}] (peso {f['peso']}) {f['trecho']}{nota}")
    sys.exit(0 if rep["verdict"] == "PASS" else 1)


if __name__ == "__main__":
    main()
